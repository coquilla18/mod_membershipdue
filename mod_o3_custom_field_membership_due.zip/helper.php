<?php
defined('_JEXEC') or die;

class ModO3_custom_field_membership_dueHelper
{
	public function getFieldsvalue($params)
    {
        $db = JFactory::getDbo();
        $query = $db->getQuery(true);
        
        $query->select('*')
                ->from('#__fields_values');
        
        $db->setQuery($query);
        $rows = $db->loadObjectList();
        
        return $rows;
    }
    
    public function loadFormData()
    {
        $data = $rows->getFieldsvalue();
        
        return $data;
    }

	
}
