<?php


defined('_JEXEC') or die;


?>



<table class="table table-striped">
  <thead class="thead-light">
    <tr>
      <th scope="col">#</th>
      <th scope="col">Item id</th>
      <th scope="col">Value</th>
    </tr>
  </thead>
  <tbody>
      <?php foreach  ($rows as $item) {?>
    <tr>
      <th scope="row"><?php echo $item->field_id; ?></th>
      <td><?php echo $item->item_id; ?></td>
      <td><?php echo $item->value; ?></td>
    </tr>
      <?php } ?>
  </tbody>
</table>