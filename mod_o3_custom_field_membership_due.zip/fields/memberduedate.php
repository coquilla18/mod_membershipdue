<?php
/**
 * @package     Joomla.Administrator
 * @subpackage  com_users
 *
 * @copyright   Copyright (C) 2005 - 2013 Open Source Matters, Inc. All rights reserved.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 */

defined('JPATH_BASE') or die;

JFormHelper::loadFieldClass('list');

/**
 * Form Field class for the Joomla Framework.
 *
 * @package     Joomla.Administrator
 * @subpackage  com_users
 * @since       1.6
 */
class JFormFieldMemberduedate extends JFormFieldList
{
	/**
	 * The form field type.
	 *
	 * @var        string
	 * @since   1.6
	 */
	protected $type = 'memberduedate';

	/**
	 * Method to get the field options.
	 *
	 * @return  array  The field option objects.
	 * @since   1.6
	 */
	protected function getOptions()
	{
		$options = array();
		$db = JFactory::getDbo();
		$query = $db->getQuery(true)
//			->select('field_id AS value, value AS text')
//                        ->select('field_id AS value,  YEAR(value) AS text')
                        ->select('EXTRACT(YEAR_MONTH FROM value) AS value,  EXTRACT(YEAR_MONTH FROM value) AS text')
                        
//			->from('#__eb_categories');
			->from('#__fields_values')
                        ->group('EXTRACT(YEAR_MONTH FROM value)');
		// Get the options.
		$db->setQuery($query);
                $db->execute();
		try
		{
			$options = $db->loadObjectList();
                        
		}
		catch (RuntimeException $e)
		{
			JError::raiseWarning(500, $e->getMessage());
		}

		// Merge any additional options in the XML definition.
		$options = array_merge(parent::getOptions(), $options);
                
                

		return $options;
	}
}
